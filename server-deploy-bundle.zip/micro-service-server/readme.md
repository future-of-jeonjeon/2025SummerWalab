## HGU-OJ Micro Service 

<img src="https://img.shields.io/badge/FastAPI-009688?style=flat-square&logo=fastapi&logoColor=white"/>
<img src="https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white"/>
<img src="https://img.shields.io/badge/Docker-2496ED?style=flat-square&logo=docker&logoColor=white"/>

### before dev
```bash 
$ python3 -m venv .venv
```

```bash 
$ source .venv/bin/activate
```


### 엔티티 수정시

```bash 
$ alembic revision --autogenerate           
```
